class FastStartException(Exception):
    """
    Raised when something bad happens during processing.
    """
    pass